﻿namespace WpfSettings.Settings
{
    public class ApplicationSettings
    {
        public int Id { get; set; }
        public string ServerUrl { get; set; }
        public bool Mode { get; set; }
    }
}
